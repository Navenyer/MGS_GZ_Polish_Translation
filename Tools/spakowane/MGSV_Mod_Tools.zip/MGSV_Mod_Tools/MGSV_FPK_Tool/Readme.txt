MGS V FPK Tool v1.2
Made by Sergeanur

DESCRIPTION
  This tool was created to unpack and repack FPK and FPKD.

USAGE
  To unpack simply drag n' drop fpk or fpkd onto MGSV_FPK_Tool.exe. The tool
  will create a folder with a filename of input file and extract all the content
  in that folder. Also the inf file will be created containing all the stuff
  needed for repacking.

  To repack simply drag n' drop inf file onto MGSV_FPK_Tool.exe.

  Don't forget to make backups!


EXTRA
* The program is using fpk_dict.txt to match hashes with real filenames.
  If you discover any filenames, add them into dictionary.txt and unpack the
  archive - the file that matches with that hash will now have its real name.
* You can try -n option to leave data unencrypted, but this mode is not tested.

2014-2015


